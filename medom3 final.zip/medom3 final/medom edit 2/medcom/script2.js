const products = [
    { id: 1, name: "Paracetamol 500mg", price: 50, image: "https://www.mccabespharmacy.com/cdn/shop/files/PfizerParacetamol500mgFilmCoatedTablets24Pack.jpg?v=1704467734", category: "medicine", rating: 4.5 },
    { id: 2, name: "Vitamin C Tablets", price: 100, image: "https://www.nutrifactor.com.pk/cdn/shop/files/NutraC.png?v=1716383636", category: "wellness", rating: 4.2 },
    { id: 3, name: "First Aid Kit (50pc)", price: 500, image: "https://image.made-in-china.com/365f3j00RzBhCyFgydoZ/First-Aid-Boxes-for-Emergency-Use-CE-ISO.webp", category: "equipment", rating: 4.8 },
    { id: 4, name: "Antiseptic Cream", price: 80, image: "https://www.bepanthen.com.au/sites/g/files/vrxlpx49316/files/2021-03/Bepanthen%20Antiseptic%20Soothing%20Cream%20100g-0new.jpg", category: "medicine", rating: 4.3 },
    { id: 5, name: "Cough Syrup", price: 120, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYqEvdEB3PYkmrHy9QRAsAlbksmhQTG9c45g&", category: "medicine", rating: 4.1 },
    { id: 6, name: "Digital Thermometer", price: 300, image: "https://www.pridesurgical.pk/wp-content/uploads/2022/12/FT65.jpg", category: "equipment", rating: 4.7 },
    { id: 7, name: "Hand Sanitizer (100ml)", price: 70, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRBRYV5a5BEc5H0kDD9If0XzlHnW0qWss5i5Q&s", category: "wellness", rating: 4.4 },
    { id: 8, name: "Bandage Roll (4m)", price: 30, image: "https://m.media-amazon.com/images/I/71px5fi7J2L._AC_UF1000,1000_QL80_.jpg", category: "equipment", rating: 4.0 }
];

function displayProducts(filteredProducts = products) {
    const container = document.getElementById("products-container");
    container.innerHTML = "";

    if (filteredProducts.length === 0) {
        document.getElementById("message").textContent = "❗ No products found matching your search!";
        return;
    }

    filteredProducts.forEach(product => {
        const productCard = document.createElement("div");
        productCard.className = "product-card";
        productCard.innerHTML = `
            <div class="product-badge">${product.category.toUpperCase()}</div>
            <img src="${product.image}" alt="${product.name}" class="product-image" />
            <div class="product-info">
                <h3>${product.name}</h3>
                <div class="product-rating">
                    ${generateStarRating(product.rating)}
                    <span>${product.rating}</span>
                </div>
                <p class="product-price">Rs. ${product.price}</p>
                <button onclick="addToCart(${product.id})" class="add-to-cart-btn">
                    <i class="fas fa-cart-plus"></i> Add to Cart
                </button>
            </div>
        `;
        container.appendChild(productCard);
    });
}

function generateStarRating(rating) {
    let stars = '';
    for (let i = 1; i <= 5; i++) {
        if (i <= Math.floor(rating)) {
            stars += '<i class="fas fa-star"></i>';
        } else if (i === Math.ceil(rating) && rating % 1 >= 0.5) {
            stars += '<i class="fas fa-star-half-alt"></i>';
        } else {
            stars += '<i class="far fa-star"></i>';
        }
    }
    return stars;
}

function filterProducts(category) {
    // Update active button
    document.querySelectorAll('.category-buttons button').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
    
    if (category === 'all') {
        displayProducts();
    } else {
        const filtered = products.filter(p => p.category === category);
        displayProducts(filtered);
    }
}

function searchProduct() {
    const keyword = document.getElementById("search").value.toLowerCase();
    const results = products.filter(product => 
        product.name.toLowerCase().includes(keyword)
    );
    document.getElementById("message").textContent = "";
    displayProducts(results);
}

function addToCart(productId) {
    localStorage.setItem("selectedProductId", productId);
    window.location.href = "cart2.html";
}

// Initialize the page
window.onload = function() {
    displayProducts();
};