from typing import List, Tuple
import heapq
from collections import deque
import matplotlib.pyplot as plt
import numpy as np
import tkinter as tk
import seaborn as sns
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

class SearchAlgorithm:
    
    @staticmethod
    def get_neighbors(x: int, y: int, grid: List[List[str]]) -> List[Tuple[int, int]]:
        directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]
        neighbors = []
        for dx, dy in directions:
            nx, ny = x + dx, y + dy
            if 0 <= nx < len(grid) and 0 <= ny < len(grid[0]) and grid[nx][ny] != '-1':
                neighbors.append((nx, ny))
        return neighbors

    @staticmethod
    def get_start_target(grid: List[List[str]]) -> Tuple[Tuple[int, int], Tuple[int, int]]:
        start, target = None, None
        for i, row in enumerate(grid):
            for j, cell in enumerate(row):
                if cell == 's':
                    start = (i, j)
                elif cell == 't':
                    target = (i, j)
        return start, target
    
    @staticmethod
    def ucs(grid: List[List[str]]) -> Tuple[int, List[Tuple[int, int]], set]:
        start, target = SearchAlgorithm.get_start_target(grid)
        pq = [(0, start)]
        visited = set()
        parent = {start: None}
        
        while pq:
            cost, current = heapq.heappop(pq)
            if current in visited:
                continue
            visited.add(current)
            
            if current == target:
                path = SearchAlgorithm.construct_path(parent, target)
                return 1, path, visited
            
            for neighbor in SearchAlgorithm.get_neighbors(*current, grid):
                if neighbor not in visited:
                    heapq.heappush(pq, (cost + 1, neighbor))
                    parent[neighbor] = current
        return -1, [], visited
    
    @staticmethod
    def dfs(grid: List[List[str]]) -> Tuple[int, List[Tuple[int, int]], set]:
        start, target = SearchAlgorithm.get_start_target(grid)
        stack = [start]
        visited = set()
        parent = {start: None}
        
        while stack:
            current = stack.pop()
            if current in visited:
                continue
            visited.add(current)
            
            if current == target:
                path = SearchAlgorithm.construct_path(parent, target)
                return 1, path, visited
            
            for neighbor in SearchAlgorithm.get_neighbors(*current, grid):
                if neighbor not in visited:
                    stack.append(neighbor)
                    parent[neighbor] = current
        return -1, [], visited
    
    @staticmethod
    def bfs(grid: List[List[str]]) -> Tuple[int, List[Tuple[int, int]], set]:
        start, target = SearchAlgorithm.get_start_target(grid)
        if not start or not target:
            return -1, [], set()
        
        queue = deque([start])
        visited = set([start])  
        parent = {start: None}
        
        while queue:
            current = queue.popleft()
            if current == target:
                path = SearchAlgorithm.construct_path(parent, target)
                return 1, path, visited
            
            for neighbor in SearchAlgorithm.get_neighbors(*current, grid):
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)
                    parent[neighbor] = current
        
        return -1, [], visited
    
    @staticmethod
    def best_first_search(grid: List[List[str]]) -> Tuple[int, List[Tuple[int, int]], set]:
        start, target = SearchAlgorithm.get_start_target(grid)
        pq = [(0, start)]
        visited = set()
        parent = {start: None}
        
        while pq:
            _, current = heapq.heappop(pq)
            if current in visited:
                continue
            visited.add(current)
            
            if current == target:
                path = SearchAlgorithm.construct_path(parent, target)
                return 1, path, visited
            
            for neighbor in SearchAlgorithm.get_neighbors(*current, grid):
                if neighbor not in visited:
                    heapq.heappush(pq, (SearchAlgorithm.manhattan_distance(neighbor, target), neighbor))
                    parent[neighbor] = current
        return -1, [], visited
    
    @staticmethod
    def a_star(grid: List[List[str]]) -> Tuple[int, List[Tuple[int, int]], set]:
        start, target = SearchAlgorithm.get_start_target(grid)
        pq = [(0, start)]
        g_cost = {start: 0}
        parent = {start: None}
        visited = set()
        
        while pq:
            _, current = heapq.heappop(pq)
            
            if current in visited:
                continue
            visited.add(current)
            
            if current == target:
                path = SearchAlgorithm.construct_path(parent, target)
                return 1, path, visited
            
            for neighbor in SearchAlgorithm.get_neighbors(*current, grid):
                new_g_cost = g_cost[current] + 1
                if neighbor not in g_cost or new_g_cost < g_cost[neighbor]:
                    g_cost[neighbor] = new_g_cost
                    f_cost = new_g_cost + SearchAlgorithm.manhattan_distance(neighbor, target)
                    heapq.heappush(pq, (f_cost, neighbor))
                    parent[neighbor] = current
        return -1, [], visited
    
    @staticmethod
    def construct_path(parent, target):
        path = []
        current = target
        while current:
            path.append(current)
            current = parent[current]
        return path[::-1]
    
    @staticmethod
    def manhattan_distance(a, b):
        return abs(a[0] - b[0]) + abs(a[1] - b[1])

class SearchVisualizerApp:
    def _init(self, root):
        self.root = root
        self.root.title("Search Algorithm Visualizer")
        
        self.grid = [
            ['5', '7', '8', '9'],
            ['3', '-1', '-1', 't'],
            ['s', '1', '-1', '0'],
            ['2', '4', '6', '-1']
        ]
        
        self.algo_var = tk.StringVar(value="BFS")
        algorithms = ["BFS", "DFS", "UCS", "Best First Search", "A*"]
        
        self.algo_menu = tk.OptionMenu(root, self.algo_var, *algorithms)
        self.algo_menu.pack(pady=10)
        
        self.run_button = tk.Button(root, text="Run Algorithm", command=self.run_algorithm)
        self.run_button.pack(pady=10)
        
        self.figure, self.ax = plt.subplots(figsize=(6, 6))
        self.canvas = FigureCanvasTkAgg(self.figure, master=root)
        self.canvas.get_tk_widget().pack()
    
    def run_algorithm(self):
        algo = self.algo_var.get()
        
        if algo == "BFS":
            found, path, visited = SearchAlgorithm.bfs(self.grid)
        elif algo == "DFS":
            found, path, visited = SearchAlgorithm.dfs(self.grid)
        elif algo == "UCS":
            found, path, visited = SearchAlgorithm.ucs(self.grid)
        elif algo == "Best First Search":
            found, path, visited = SearchAlgorithm.best_first_search(self.grid)
        elif algo == "A*":
            found, path, visited = SearchAlgorithm.a_star(self.grid)
        else:
            return
        
        grid_output = [[0 for _ in row] for row in self.grid]
        for x, y in visited:
            grid_output[x][y] = 1
        for x, y in path:
            grid_output[x][y] = 2
        
        heatmap_data = np.array(grid_output)
        
        cmap = plt.cm.colors.ListedColormap(['white', 'lightpink', 'blue'])
        
        self.ax.clear()
        
        sns.heatmap(
            heatmap_data, 
            annot=np.array(self.grid),
            cmap=cmap, 
            cbar=False, 
            linewidths=2, 
            linecolor='black', 
            fmt='', 
            ax=self.ax
        )
        self.ax.set_title(f"{algo} Path Visualization")
        
        self.canvas.draw()

if _name_ == "_main_":
    root = tk.Tk()
    app = SearchVisualizerApp(root)
    root.mainloop()
