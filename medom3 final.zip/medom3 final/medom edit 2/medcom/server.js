const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(bodyParser.json());
app.use(cors());

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/medcom', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
    .then(() => {
        console.log('MongoDB connected');
    })
    .catch((error) => {
        console.error('Error connecting to MongoDB:', error);
    });

// Company Schema and Model
const companySchema = new mongoose.Schema({
    name: String,
    status: String, // "approved" or "rejected"
});

const Company = mongoose.model('Company', companySchema);

// Order Schema and Model
const orderSchema = new mongoose.Schema({
    productName: String,
    quantity: Number,
    customerName: String,
    customerEmail: String,
    status: { type: String, default: 'Pending' }, // "Pending", "Completed"
    date: { type: Date, default: Date.now },
});

const Order = mongoose.model('Order', orderSchema);

// User Schema
const userSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    resetToken: String,
    resetTokenExpiry: Date
});

const User = mongoose.model('User', userSchema);

// Fetch all companies
app.get('/companies', async (req, res) => {
    try {
        const companies = await Company.find();
        res.status(200).send(companies);
    } catch (error) {
        console.error('Error fetching companies:', error);
        res.status(500).send({ error: 'Failed to fetch companies' });
    }
});

// Approve a company by name
app.post('/approve', async (req, res) => {
    const { name } = req.body;
    console.log('Approve Request Received:', req.body);
    if (!name) {
        console.error('Error: Company name is missing');
        return res.status(400).send({ error: 'Company name is required' });
    }
    try {
        const company = await Company.findOneAndUpdate(
            { name },
            { status: 'approved' },
            { new: true }
        );
        if (!company) {
            console.error('Error: Company not found for name:', name);
            return res.status(404).send({ error: 'Company not found' });
        }
        console.log('Company Approved:', company);
        res.status(200).send({ message: 'Company approved successfully', company });
    } catch (error) {
        console.error('Error approving company:', error);
        res.status(500).send({ error: 'Failed to approve company' });
    }
});

// Reject a company by name
app.post('/reject', async (req, res) => {
    const { name } = req.body;
    console.log('Reject Request Received:', req.body);
    if (!name) {
        console.error('Error: Company name is missing');
        return res.status(400).send({ error: 'Company name is required' });
    }
    try {
        const company = await Company.findOneAndUpdate(
            { name },
            { status: 'rejected' },
            { new: true }
        );
        if (!company) {
            console.error('Error: Company not found for name:', name);
            return res.status(404).send({ error: 'Company not found' });
        }
        console.log('Company Rejected:', company);
        res.status(200).send({ message: 'Company rejected successfully', company });
    } catch (error) {
        console.error('Error rejecting company:', error);
        res.status(500).send({ error: 'Failed to reject company' });
    }
});

// Endpoint to place an order
app.post('/place-order', async (req, res) => {
    console.log('Order Placement Request Received:', req.body); // Log the request body
    const { productName, quantity } = req.body;

    if (!productName || !quantity) {
        console.error('Error: Missing fields in order placement');
        return res.status(400).send({ error: 'Medicine name and quantity are required' });
    }

    try {
        const newOrder = new Order({ productName, quantity });
        await newOrder.save();
        console.log('Order Saved:', newOrder); // Log the saved order
        res.status(201).send({ message: 'Order placed successfully', order: newOrder });
    } catch (error) {
        console.error('Error placing order:', error);
        res.status(500).send({ error: 'Failed to place order' });
    }
});

// Endpoint to fetch all orders (for admin)
app.get('/orders', async (req, res) => {
    try {
        const orders = await Order.find();
        console.log('Orders Retrieved:', orders);
        res.status(200).send(orders);
    } catch (error) {
        console.error('Error fetching orders:', error);
        res.status(500).send({ error: 'Failed to fetch orders' });
    }
});

// Auth Routes
app.post('/signup', async (req, res) => {
    const { username, email, password } = req.body;
    try {
        const existingUser = await User.findOne({ $or: [{ email }, { username }] });
        if (existingUser) {
            return res.status(400).json({ error: 'User already exists' });
        }
        const user = new User({ username, email, password });
        await user.save();
        res.status(201).json({ message: 'User created successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Error creating user' });
    }
});

app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await User.findOne({ email });
        if (!user || user.password !== password) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        res.status(200).json({ message: 'Login successful' });
    } catch (error) {
        res.status(500).json({ error: 'Error logging in' });
    }
});

app.post('/reset-password', async (req, res) => {
    const { email } = req.body;
    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        const resetToken = Math.random().toString(36).slice(-8);
        user.resetToken = resetToken;
        user.resetTokenExpiry = Date.now() + 3600000; // 1 hour
        await user.save();
        res.status(200).json({ message: 'Password reset token generated' });
    } catch (error) {
        res.status(500).json({ error: 'Error resetting password' });
    }
});

// Start the server
app.listen(5000, () => {
    console.log('Server running on port 5000');
});