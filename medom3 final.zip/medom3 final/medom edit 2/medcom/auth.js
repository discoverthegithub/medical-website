// User database simulation (in a real app, use a backend database)
let users = JSON.parse(localStorage.getItem('users')) || [];

// Utility functions
const validateEmail = (email) => {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
};

const validatePassword = (password) => {
  // At least 8 chars, 1 uppercase, 1 lowercase, 1 number
  const re = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
  return re.test(password);
};

// Signup functionality
const handleSignup = (e) => {
  e.preventDefault();
  
  const username = document.getElementById('username').value;
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  if (!validateEmail(email)) {
    alert('Please enter a valid email address');
    return;
  }

  if (!validatePassword(password)) {
    alert('Password must be at least 8 characters with 1 uppercase, 1 lowercase, and 1 number');
    return;
  }

  // Check if user exists
  if (users.some(user => user.email === email)) {
    alert('Email already registered');
    return;
  }

  // Add new user
  users.push({ username, email, password });
  localStorage.setItem('users', JSON.stringify(users));
  
  alert('Registration successful! Please login.');
  window.location.href = 'login.html';
};

// Login functionality
const handleLogin = (e) => {
  e.preventDefault();
  
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  const user = users.find(user => user.email === email);
  
  if (!user) {
    alert('Email not found. Please sign up.');
    return;
  }

  if (user.password !== password) {
    alert('Incorrect password');
    return;
  }

  // Store logged in user (in a real app, use proper session management)
  localStorage.setItem('currentUser', JSON.stringify(user));
  alert('Login successful!');
  window.location.href = 'index.html'; // Redirect to home page
};

// Forgot password functionality
const handleForgotPassword = (e) => {
  e.preventDefault();
  
  const email = document.getElementById('email').value;
  
  if (!validateEmail(email)) {
    alert('Please enter a valid email address');
    return;
  }

  const user = users.find(user => user.email === email);
  
  if (!user) {
    alert('Email not found in our system');
    return;
  }

  alert(`Password reset link sent to ${email} (simulated)`);
  // In a real app, send actual reset link
};

// Update password functionality
const handleUpdatePassword = (e) => {
  e.preventDefault();
  
  const currentPassword = document.getElementById('currentPassword').value;
  const newPassword = document.getElementById('newPassword').value;
  const confirmPassword = document.getElementById('confirmPassword').value;

  const currentUser = JSON.parse(localStorage.getItem('currentUser'));
  
  if (!currentUser) {
    alert('Please login first');
    window.location.href = 'login.html';
    return;
  }

  if (currentUser.password !== currentPassword) {
    alert('Current password is incorrect');
    return;
  }

  if (newPassword !== confirmPassword) {
    alert('New passwords do not match');
    return;
  }

  if (!validatePassword(newPassword)) {
    alert('Password must be at least 8 characters with 1 uppercase, 1 lowercase, and 1 number');
    return;
  }

  // Update password
  users = users.map(user => 
    user.email === currentUser.email ? { ...user, password: newPassword } : user
  );
  
  localStorage.setItem('users', JSON.stringify(users));
  localStorage.setItem('currentUser', JSON.stringify({
    ...currentUser,
    password: newPassword
  }));
  
  alert('Password updated successfully!');
};

// Initialize forms
document.addEventListener('DOMContentLoaded', () => {
  // Signup form
  if (document.querySelector('#signup form')) {
    document.querySelector('#signup form').addEventListener('submit', handleSignup);
  }
  
  // Login form
  if (document.querySelector('#login form')) {
    document.querySelector('#login form').addEventListener('submit', handleLogin);
  }
  
  // Forgot password form
  if (document.querySelector('#forgot form')) {
    document.querySelector('#forgot form').addEventListener('submit', handleForgotPassword);
  }
  
  // Update password form (you'll need to create this page)
  if (document.querySelector('#update-password form')) {
    document.querySelector('#update-password form').addEventListener('submit', handleUpdatePassword);
  }
});