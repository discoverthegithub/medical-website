document.querySelector('#update-password form').addEventListener('submit', function (e) {
    e.preventDefault();

    const currentPassword = document.getElementById('currentPassword').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    if (newPassword !== confirmPassword) {
        alert('New password and confirm password do not match!');
        return;
    }

    // Simulate API call for password update
    console.log('Updating password...');
    setTimeout(() => {
        alert('Password updated successfully!');
        document.querySelector('#update-password form').reset();
    }, 1000);
});