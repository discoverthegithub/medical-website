const express = require('express');
const {
    addProduct,
    updateProduct,
    removeProduct,
    getProducts,
    viewOrders,
    updateOrderStatus,
    monitorStock,
    updateStockLevels,
    approveCompany,
    rejectCompany,
    managePaymentMethods,
    manageDeliveryOptions,
} = require('../controllers/adminController');

const router = express.Router();

// Product Management
router.post('/products', addProduct); // Add a product
router.get('/products', getProducts); // Get all products
router.put('/products/:id', updateProduct); // Update a product
router.delete('/products/:id', removeProduct); // Delete a product

// Order Management
router.get('/orders', viewOrders); // View all orders
router.put('/orders/:id', updateOrderStatus); // Update order status

// Inventory Management
router.get('/inventory', monitorStock); // Monitor stock
router.put('/inventory/:id', updateStockLevels); // Update stock levels

// Approval Management
router.put('/companies/:id/approve', approveCompany); // Approve a company
router.put('/companies/:id/reject', rejectCompany); // Reject a company

// Website Settings
router.post('/settings/payment-methods', managePaymentMethods); // Manage payment methods
router.post('/settings/delivery-options', manageDeliveryOptions); // Manage delivery options

const Company = require('../models/company'); // Ensure this line exists
// Fetch Approved Companies
router.get('/companies/approved', async (req, res) => {
    try {
        const approvedCompanies = await Company.find({ status: 'Approved' });
        res.status(200).json(approvedCompanies);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Add debugging logs to the rejected companies route
router.get('/companies/rejected', async (req, res) => {
    try {
        console.log('Fetching rejected companies...'); // Debugging log
        const rejectedCompanies = await Company.find({ status: 'Rejected' });
        console.log('Rejected companies:', rejectedCompanies); // Debugging log
        res.status(200).json(rejectedCompanies);
    } catch (err) {
        console.error('Error fetching rejected companies:', err); // Debugging log
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;