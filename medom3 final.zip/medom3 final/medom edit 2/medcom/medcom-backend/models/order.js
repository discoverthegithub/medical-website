const mongoose = require('mongoose');

const OrderSchema = new mongoose.Schema({
    customerName: { type: String, required: true },
    status: { type: String, enum: ['Processing', 'Shipped', 'Completed'], default: 'Processing' },
    products: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Product' }],
});

module.exports = mongoose.models.Order || mongoose.model('Order', OrderSchema);