const Product = require('../models/product');
const Order = require('../models/order');
const Company = require('../models/company');

// Add Product
exports.addProduct = async (req, res) => {
    try {
        const { name, price, stock } = req.body;
        const product = new Product({ name, price, stock });
        await product.save();
        res.status(201).json({ message: 'Product added successfully', product });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Get All Products
exports.getProducts = async (req, res) => {
    try {
        const products = await Product.find();
        res.status(200).json(products);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Update Product
exports.updateProduct = async (req, res) => {
    try {
        const { id } = req.params;
        const { name, price, stock } = req.body;
        const product = await Product.findByIdAndUpdate(id, { name, price, stock }, { new: true });
        res.status(200).json({ message: 'Product updated successfully', product });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Remove Product
exports.removeProduct = async (req, res) => {
    try {
        const { id } = req.params;
        await Product.findByIdAndDelete(id);
        res.status(200).json({ message: 'Product removed successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// View Orders
exports.viewOrders = async (req, res) => {
    try {
        const orders = await Order.find().populate('products');
        res.status(200).json(orders);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Update Order Status
exports.updateOrderStatus = async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;
        const order = await Order.findByIdAndUpdate(id, { status }, { new: true });
        res.status(200).json({ message: 'Order status updated successfully', order });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Monitor Stock
exports.monitorStock = async (req, res) => {
    try {
        const products = await Product.find();
        res.status(200).json(products);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Update Stock Levels
exports.updateStockLevels = async (req, res) => {
    try {
        const { id } = req.params;
        const { stock } = req.body;
        const product = await Product.findByIdAndUpdate(id, { stock }, { new: true });
        res.status(200).json({ message: 'Stock updated successfully', product });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};



// Approve Company
exports.approveCompany = async (req, res) => {
    try {
        const { id } = req.params;
        const company = await Company.findByIdAndUpdate(id, { status: 'Approved' }, { new: true });
        if (!company) {
            return res.status(404).json({ error: 'Company not found' });
        }
        res.status(200).json({ message: 'Company approved successfully', company });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Reject Company
exports.rejectCompany = async (req, res) => {
    try {
        const { id } = req.params;
        const company = await Company.findByIdAndUpdate(id, { status: 'Rejected' }, { new: true });
        if (!company) {
            return res.status(404).json({ error: 'Company not found' });
        }
        res.status(200).json({ message: 'Company rejected successfully', company });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Manage Payment Methods
exports.managePaymentMethods = async (req, res) => {
    try {
        const { paymentMethods } = req.body; // Example: ['Credit Card', 'PayPal']
        // Save or update payment methods in your database (not implemented here)
        res.status(200).json({ message: 'Payment methods updated successfully', paymentMethods });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Manage Delivery Options
exports.manageDeliveryOptions = async (req, res) => {
    try {
        const { deliveryOptions } = req.body; // Example: ['Standard', 'Express']
        // Save or update delivery options in your database (not implemented here)
        res.status(200).json({ message: 'Delivery options updated successfully', deliveryOptions });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};