// Utility function to close modals
function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Utility function to open modals
function openModal(modalId) {
    document.getElementById(modalId).style.display = 'block';
}

// ==================== Product Management ====================

// Add Product
document.getElementById('addProductForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('productName').value;
    const price = document.getElementById('productPrice').value;
    const stock = document.getElementById('productStock').value;

    try {
        const response = await fetch('http://localhost:5000/api/admin/products', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, price, stock }),
        });

        if (response.ok) {
            alert('Product added successfully!');
            closeModal('addProductModal');
        } else {
            const error = await response.json();
            alert(`Error: ${error.error}`);
        }
    } catch (err) {
        console.error('Error adding product:', err);
    }
});

// Update Product
async function updateProduct() {
    const productId = prompt('Enter the Product ID to update:');
    const name = prompt('Enter the new product name:');
    const price = prompt('Enter the new product price:');
    const stock = prompt('Enter the new product stock:');

    try {
        const response = await fetch(`http://localhost:5000/api/admin/products/${productId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, price, stock }),
        });

        if (response.ok) {
            alert('Product updated successfully!');
        } else {
            const error = await response.json();
            alert(`Error: ${error.error}`);
        }
    } catch (err) {
        console.error('Error updating product:', err);
    }
}

// Remove Product
async function removeProduct() {
    const productId = prompt('Enter the Product ID to remove:');

    try {
        const response = await fetch(`http://localhost:5000/api/admin/products/${productId}`, {
            method: 'DELETE',
        });

        if (response.ok) {
            alert('Product removed successfully!');
        } else {
            const error = await response.json();
            alert(`Error: ${error.error}`);
        }
    } catch (err) {
        console.error('Error removing product:', err);
    }
}

// View Stock
async function viewStock() {
    try {
        const response = await fetch('http://localhost:5000/api/admin/products');
        const products = await response.json();

        const stockList = document.getElementById('stockList');
        stockList.innerHTML = ''; // Clear existing stock list

        products.forEach((product) => {
            const productItem = document.createElement('div');
            productItem.className = 'product-item';
            productItem.innerHTML = `
                <h3>${product.name}</h3>
                <p>Price: $${product.price}</p>
                <p>Stock: ${product.stock}</p>
            `;
            stockList.appendChild(productItem);
        });
    } catch (err) {
        console.error('Error fetching stock:', err);
    }
}

// ==================== Order Management ====================

// View Orders
async function viewOrders() {
    try {
        const response = await fetch('http://localhost:5000/api/admin/orders');
        const orders = await response.json();
        console.log('Orders:', orders);
        alert('Orders fetched successfully! Check the console for details.');
    } catch (err) {
        console.error('Error fetching orders:', err);
    }
}

// ==================== Approval Management ====================

// Approve Company
async function approveCompany() {
    const companyName = prompt("Enter the name of the company to approve:");
    if (companyName) {
        try {
            console.log('Sending Approve Request for Name:', companyName); // Log the name
            const response = await fetch('http://localhost:5000/approve', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name: companyName }),
            });
            const result = await response.json();
            console.log('Approve Response:', result); // Log the response
            if (response.ok) {
                alert(result.message);
            } else {
                alert(result.error);
            }
        } catch (error) {
            console.error('Error approving company:', error); // Log the error
            alert('Failed to approve company. Please try again.');
        }
    }
}

// Reject Company
async function rejectCompany() {
    const companyName = prompt("Enter the name of the company to reject:");
    if (companyName) {
        try {
            console.log('Sending Reject Request for Name:', companyName); // Log the name
            const response = await fetch('http://localhost:5000/reject', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name: companyName }),
            });
            const result = await response.json();
            console.log('Reject Response:', result); // Log the response
            if (response.ok) {
                alert(result.message);
            } else {
                alert(result.error);
            }
        } catch (error) {
            console.error('Error rejecting company:', error); // Log the error
            alert('Failed to reject company. Please try again.');
        }
    }
}

// View Approved Companies
async function viewApprovedCompanies() {
    console.log('View Approved Companies button clicked'); // Debugging log
    try {
        const response = await fetch('http://localhost:5000/api/admin/companies/approved');
        if (!response.ok) {
            throw new Error('Failed to fetch approved companies');
        }
        const companies = await response.json();

        const approvedCompaniesList = document.getElementById('approvedCompaniesList');
        approvedCompaniesList.innerHTML = '<h3>Approved Companies</h3>'; // Clear and add heading

        if (companies.length === 0) {
            approvedCompaniesList.innerHTML += '<p>No approved companies found.</p>';
            return;
        }

        companies.forEach((company) => {
            const companyItem = document.createElement('div');
            companyItem.className = 'company-item';
            companyItem.innerHTML = `
                <p><strong>ID:</strong> ${company._id}</p>
                <p><strong>Name:</strong> ${company.name || 'N/A'}</p>
                <p><strong>Status:</strong> ${company.status}</p>
            `;
            approvedCompaniesList.appendChild(companyItem);
        });
    } catch (err) {
        console.error('Error fetching approved companies:', err);
        alert('Error fetching approved companies. Check the console for details.');
    }
}

// View Rejected Companies
async function viewRejectedCompanies() {
    console.log('View Rejected Companies button clicked'); // Debugging log
    try {
        const response = await fetch('http://localhost:5000/api/admin/companies/rejected');
        if (!response.ok) {
            throw new Error('Failed to fetch rejected companies');
        }
        const companies = await response.json();

        const rejectedCompaniesList = document.getElementById('rejectedCompaniesList');
        rejectedCompaniesList.innerHTML = '<h3>Rejected Companies</h3>'; // Clear and add heading

        if (companies.length === 0) {
            rejectedCompaniesList.innerHTML += '<p>No rejected companies found.</p>';
            return;
        }

        companies.forEach((company) => {
            const companyItem = document.createElement('div');
            companyItem.className = 'company-item';
            companyItem.innerHTML = `
                <p><strong>ID:</strong> ${company._id}</p>
                <p><strong>Name:</strong> ${company.name || 'N/A'}</p>
                <p><strong>Status:</strong> ${company.status}</p>
            `;
            rejectedCompaniesList.appendChild(companyItem);
        });
    } catch (err) {
        console.error('Error fetching rejected companies:', err);
        alert('Error fetching rejected companies. Check the console for details.');
    }
}

let approvedCompanies = [];
let rejectedCompanies = [];

function viewApprovedCompanies() {
    const approvedList = document.getElementById("approvedCompaniesList");
    approvedList.innerHTML = approvedCompanies.map(name => `<li>${name}</li>`).join('');
}

function viewRejectedCompanies() {
    const rejectedList = document.getElementById("rejectedCompaniesList");
    rejectedList.innerHTML = rejectedCompanies.map(name => `<li>${name}</li>`).join('');
}